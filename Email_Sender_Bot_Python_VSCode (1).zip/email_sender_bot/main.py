"""
Email Sender Bot
=================
A modular Gmail SMTP email automation application with a Tkinter GUI.

Run:
    python main.py

Security:
    Set EMAIL_SENDER and EMAIL_APP_PASSWORD as environment variables.
    Never put your Gmail App Password directly into source code.
"""

from email_bot.gui import EmailSenderApp


def main():
    """Application entry point."""
    app = EmailSenderApp()
    app.run()


if __name__ == "__main__":
    main()
