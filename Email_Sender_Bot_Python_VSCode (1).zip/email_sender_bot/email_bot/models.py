"""Data models used by the application."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Recipient:
    """Represents one email recipient."""

    name: str
    email: str
    company: str = ""
    subject: str = ""

    def variables(self) -> dict:
        """Return fields available to the message template."""
        return {
            "name": self.name,
            "email": self.email,
            "company": self.company,
        }


@dataclass
class SendResult:
    """Stores the result of one email delivery attempt."""

    name: str
    email: str
    status: str
    attempts: int
    error: str = ""
    timestamp: str = ""


@dataclass
class SendSummary:
    """Stores aggregate sending statistics."""

    total: int = 0
    successful: int = 0
    failed: int = 0
    skipped: int = 0
    results: list[SendResult] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        """Return successful delivery percentage."""
        if self.total == 0:
            return 0.0
        return (self.successful / self.total) * 100
