"""SMTP email engine with attachments and retry logic."""

from email.message import EmailMessage
from pathlib import Path
import mimetypes
import smtplib
import time

from .config import (
    MAX_RETRIES,
    RETRY_DELAY_SECONDS,
    SMTP_PORT,
    SMTP_SERVER,
)
from .models import Recipient, SendResult, SendSummary
from .template_manager import personalize


class EmailEngine:
    """Manages SMTP connection and email delivery."""

    def __init__(self, sender_email: str, app_password: str, logger=None):
        self.sender_email = sender_email
        self.app_password = app_password
        self.logger = logger
        self.server = None

    def connect(self):
        """Connect and authenticate with Gmail SMTP."""
        self.server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=30)
        self.server.ehlo()
        self.server.starttls()
        self.server.ehlo()
        self.server.login(self.sender_email, self.app_password)

    def disconnect(self):
        """Close the SMTP connection safely."""
        if self.server is not None:
            try:
                self.server.quit()
            except (OSError, smtplib.SMTPException):
                try:
                    self.server.close()
                except Exception:
                    pass
            finally:
                self.server = None

    def build_message(
        self,
        recipient: Recipient,
        subject: str,
        template: str,
        attachments: list[str],
    ) -> EmailMessage:
        """Build a complete email message."""
        message = EmailMessage()
        message["From"] = self.sender_email
        message["To"] = recipient.email
        message["Subject"] = recipient.subject.strip() or subject
        message.set_content(personalize(template, recipient))

        for attachment in attachments:
            self._attach_file(message, Path(attachment))

        return message

    @staticmethod
    def _attach_file(message: EmailMessage, path: Path):
        """Attach a local file using its detected MIME type."""
        if not path.exists():
            raise FileNotFoundError(f"Attachment not found: {path}")

        mime_type, _ = mimetypes.guess_type(path.name)
        if mime_type:
            maintype, subtype = mime_type.split("/", 1)
        else:
            maintype, subtype = "application", "octet-stream"

        data = path.read_bytes()
        message.add_attachment(
            data,
            maintype=maintype,
            subtype=subtype,
            filename=path.name,
        )

    def send_one(
        self,
        recipient: Recipient,
        subject: str,
        template: str,
        attachments: list[str],
    ):
        """Send one message over the active connection."""
        if self.server is None:
            raise RuntimeError("SMTP connection is not active.")

        message = self.build_message(
            recipient, subject, template, attachments
        )
        self.server.send_message(message)

    def send_with_retry(
        self,
        recipient: Recipient,
        subject: str,
        template: str,
        attachments: list[str],
        max_retries: int = MAX_RETRIES,
        retry_delay: int = RETRY_DELAY_SECONDS,
    ) -> SendResult:
        """Send one message with retry support."""
        last_error = ""

        for attempt in range(1, max_retries + 1):
            try:
                self.send_one(recipient, subject, template, attachments)
                return SendResult(
                    name=recipient.name,
                    email=recipient.email,
                    status="SUCCESS",
                    attempts=attempt,
                )
            except Exception as exc:
                last_error = str(exc)
                if self.logger:
                    self.logger.warning(
                        "Attempt %s/%s failed for %s: %s",
                        attempt,
                        max_retries,
                        recipient.email,
                        exc,
                    )
                if attempt < max_retries:
                    time.sleep(retry_delay)

        return SendResult(
            name=recipient.name,
            email=recipient.email,
            status="FAILED",
            attempts=max_retries,
            error=last_error,
        )

    def send_bulk(
        self,
        recipients: list[Recipient],
        subject: str,
        template: str,
        attachments: list[str],
        progress_callback=None,
        stop_callback=None,
    ) -> SendSummary:
        """Send messages to all recipients."""
        summary = SendSummary(total=len(recipients))

        for index, recipient in enumerate(recipients, start=1):
            if stop_callback and stop_callback():
                summary.skipped = len(recipients) - index + 1
                break

            result = self.send_with_retry(
                recipient,
                subject,
                template,
                attachments,
            )
            summary.results.append(result)

            if result.status == "SUCCESS":
                summary.successful += 1
            else:
                summary.failed += 1

            if progress_callback:
                progress_callback(index, len(recipients), result)

        return summary
