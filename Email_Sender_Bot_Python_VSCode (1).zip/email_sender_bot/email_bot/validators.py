"""Validation helpers."""

import re


EMAIL_PATTERN = re.compile(
    r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@"
    r"[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+$"
)


def is_valid_email(email: str) -> bool:
    """Validate an email address format."""
    return bool(EMAIL_PATTERN.fullmatch(email.strip()))


def validate_recipient(name: str, email: str) -> tuple[bool, str]:
    """Validate required recipient fields."""
    if not name.strip():
        return False, "Name is required."
    if not email.strip():
        return False, "Email is required."
    if not is_valid_email(email):
        return False, "Invalid email address."
    return True, ""


def validate_subject(subject: str) -> tuple[bool, str]:
    """Validate email subject."""
    if not subject.strip():
        return False, "Subject cannot be empty."
    return True, ""


def validate_template(template: str) -> tuple[bool, str]:
    """Validate that an email template is not empty."""
    if not template.strip():
        return False, "Message template cannot be empty."
    return True, ""


def validate_attachment(path: str) -> tuple[bool, str]:
    """Validate attachment path when supplied."""
    from pathlib import Path

    if not path.strip():
        return True, ""

    file_path = Path(path)
    if not file_path.exists():
        return False, "Attachment does not exist."
    if not file_path.is_file():
        return False, "Attachment path is not a file."
    return True, ""
