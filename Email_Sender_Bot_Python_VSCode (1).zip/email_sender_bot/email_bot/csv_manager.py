"""CSV recipient management."""

import csv
from pathlib import Path

from .models import Recipient
from .validators import is_valid_email


REQUIRED_COLUMNS = {"name", "email"}


def load_recipients(path: Path) -> tuple[list[Recipient], list[str]]:
    """
    Load recipients from CSV.

    Accepted columns:
        name,email,company,subject

    Returns:
        (valid_recipients, warnings)
    """
    recipients = []
    warnings = []

    if not path.exists():
        return [], [f"Recipient file not found: {path}"]

    try:
        with path.open("r", newline="", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)

            if not reader.fieldnames:
                return [], ["CSV file has no header row."]

            columns = {c.strip().lower() for c in reader.fieldnames if c}
            missing = REQUIRED_COLUMNS - columns
            if missing:
                return [], [f"Missing required columns: {', '.join(sorted(missing))}"]

            for line_no, row in enumerate(reader, start=2):
                normalized = {
                    (key or "").strip().lower(): (value or "").strip()
                    for key, value in row.items()
                }

                name = normalized.get("name", "")
                email = normalized.get("email", "")
                company = normalized.get("company", "")
                subject = normalized.get("subject", "")

                if not name or not email:
                    warnings.append(f"Line {line_no}: missing name or email.")
                    continue

                if not is_valid_email(email):
                    warnings.append(f"Line {line_no}: invalid email '{email}'.")
                    continue

                recipients.append(
                    Recipient(
                        name=name,
                        email=email,
                        company=company,
                        subject=subject,
                    )
                )
    except OSError as exc:
        return [], [f"Could not read CSV: {exc}"]
    except csv.Error as exc:
        return [], [f"CSV parsing error: {exc}"]

    return recipients, warnings


def save_sample_csv(path: Path):
    """Create a sample recipient CSV if one does not exist."""
    if path.exists():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["name", "email", "company", "subject"])
        writer.writerow(
            ["Demo User", "replace-with-your-email@example.com", "Demo Company", ""]
        )


def count_recipients(recipients: list[Recipient]) -> int:
    """Return recipient count."""
    return len(recipients)
