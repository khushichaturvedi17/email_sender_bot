"""Application logging and send-status CSV reporting."""

import csv
import logging
from datetime import datetime
from pathlib import Path

from .models import SendResult


def create_logger(log_path: Path) -> logging.Logger:
    """Create a rotating-safe application logger."""
    log_path.parent.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("EmailSenderBot")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if not logger.handlers:
        handler = logging.FileHandler(log_path, encoding="utf-8")
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger


def write_status_report(path: Path, results: list[SendResult]):
    """Write delivery results to a CSV report."""
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            ["timestamp", "name", "email", "status", "attempts", "error"]
        )

        for result in results:
            writer.writerow(
                [
                    result.timestamp
                    or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    result.name,
                    result.email,
                    result.status,
                    result.attempts,
                    result.error,
                ]
            )
