"""Application configuration and environment helpers."""

from pathlib import Path
import os

APP_NAME = "Email Sender Bot"
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
ATTACHMENTS_DIR = BASE_DIR / "attachments"
LOGS_DIR = BASE_DIR / "logs"

RECIPIENT_FILE = DATA_DIR / "recipients.csv"
TEMPLATE_FILE = DATA_DIR / "template.txt"
LOG_FILE = LOGS_DIR / "email_sender.log"
STATUS_FILE = LOGS_DIR / "send_status.csv"

MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 3
DEFAULT_SUBJECT = "Important Report"
DEFAULT_TEMPLATE = """Hello {name},

I hope you are doing well.

Please find the requested report attached.

Regards,
Email Sender Bot
"""


def ensure_directories():
    """Create required application directories."""
    for folder in (DATA_DIR, ATTACHMENTS_DIR, LOGS_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def get_sender_email():
    """Return sender email from the environment."""
    return os.getenv("EMAIL_SENDER", "").strip()


def get_app_password():
    """Return Gmail App Password from the environment."""
    return os.getenv("EMAIL_APP_PASSWORD", "").strip()
