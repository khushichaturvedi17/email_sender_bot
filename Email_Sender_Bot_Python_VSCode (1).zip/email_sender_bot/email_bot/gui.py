"""Tkinter graphical user interface for Email Sender Bot."""

from pathlib import Path
import os
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .config import (
    APP_NAME,
    ATTACHMENTS_DIR,
    DEFAULT_SUBJECT,
    LOG_FILE,
    RECIPIENT_FILE,
    STATUS_FILE,
    TEMPLATE_FILE,
    ensure_directories,
    get_app_password,
    get_sender_email,
)
from .csv_manager import load_recipients, save_sample_csv
from .email_engine import EmailEngine
from .logger import create_logger, write_status_report
from .models import Recipient, SendResult, SendSummary
from .template_manager import load_template, save_template, personalize
from .validators import (
    validate_attachment,
    validate_subject,
    validate_template,
)


class EmailSenderApp:
    """Main desktop application."""

    def __init__(self):
        ensure_directories()
        save_sample_csv(RECIPIENT_FILE)

        self.root = tk.Tk()
        self.root.title(APP_NAME)
        self.root.geometry("1080x760")
        self.root.minsize(900, 650)

        self.logger = create_logger(LOG_FILE)
        self.recipients: list[Recipient] = []
        self.attachments: list[str] = []
        self.last_summary: SendSummary | None = None
        self.stop_requested = False
        self.sender_thread = None

        self.sender_var = tk.StringVar(value=get_sender_email())
        self.password_var = tk.StringVar()
        self.subject_var = tk.StringVar(value=DEFAULT_SUBJECT)
        self.csv_var = tk.StringVar(value=str(RECIPIENT_FILE))
        self.status_var = tk.StringVar(value="Ready.")
        self.progress_var = tk.DoubleVar(value=0)
        self.count_var = tk.StringVar(value="0 recipients loaded")

        self._build_style()
        self._build_ui()
        self._load_template_into_editor()
        self._load_recipients(silent=True)

    def _build_style(self):
        """Configure ttk styling."""
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"))
        style.configure("Heading.TLabel", font=("Segoe UI", 12, "bold"))
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"))

    def _build_ui(self):
        """Build all interface sections."""
        outer = ttk.Frame(self.root, padding=16)
        outer.pack(fill="both", expand=True)

        ttk.Label(
            outer,
            text="EMAIL SENDER BOT",
            style="Title.TLabel",
        ).pack(anchor="w")

        ttk.Label(
            outer,
            text="Gmail SMTP automation • CSV recipients • personalization • attachments • retry • logs",
        ).pack(anchor="w", pady=(2, 14))

        notebook = ttk.Notebook(outer)
        notebook.pack(fill="both", expand=True)

        self._build_compose_tab(notebook)
        self._build_recipients_tab(notebook)
        self._build_results_tab(notebook)
        self._build_help_tab(notebook)

        bottom = ttk.Frame(outer)
        bottom.pack(fill="x", pady=(12, 0))

        ttk.Label(
            bottom,
            textvariable=self.status_var,
        ).pack(side="left")

        ttk.Progressbar(
            bottom,
            variable=self.progress_var,
            maximum=100,
            length=300,
        ).pack(side="right")

    def _build_compose_tab(self, notebook):
        """Build sender credentials and message editor."""
        tab = ttk.Frame(notebook, padding=14)
        notebook.add(tab, text="Compose & Send")

        credentials = ttk.LabelFrame(
            tab, text="Gmail Account", padding=12
        )
        credentials.pack(fill="x")

        ttk.Label(credentials, text="Sender email:").grid(
            row=0, column=0, sticky="w", padx=4, pady=4
        )
        ttk.Entry(
            credentials,
            textvariable=self.sender_var,
            width=45,
        ).grid(row=0, column=1, sticky="ew", padx=4, pady=4)

        ttk.Label(credentials, text="App Password:").grid(
            row=1, column=0, sticky="w", padx=4, pady=4
        )
        ttk.Entry(
            credentials,
            textvariable=self.password_var,
            show="•",
            width=45,
        ).grid(row=1, column=1, sticky="ew", padx=4, pady=4)

        ttk.Label(
            credentials,
            text="The password is used only for this run and is not saved.",
        ).grid(row=2, column=1, sticky="w", padx=4, pady=(0, 4))

        credentials.columnconfigure(1, weight=1)

        message_box = ttk.LabelFrame(
            tab, text="Message", padding=12
        )
        message_box.pack(fill="both", expand=True, pady=12)

        ttk.Label(message_box, text="Subject:").pack(anchor="w")
        ttk.Entry(
            message_box,
            textvariable=self.subject_var,
        ).pack(fill="x", pady=(2, 8))

        ttk.Label(
            message_box,
            text="Template placeholders: {name}, {email}, {company}",
        ).pack(anchor="w")

        self.message_text = tk.Text(
            message_box,
            height=13,
            wrap="word",
            font=("Consolas", 10),
        )
        self.message_text.pack(fill="both", expand=True, pady=(4, 8))

        actions = ttk.Frame(message_box)
        actions.pack(fill="x")

        ttk.Button(
            actions,
            text="Save Template",
            command=self._save_template,
        ).pack(side="left", padx=(0, 6))

        ttk.Button(
            actions,
            text="Preview",
            command=self._preview_email,
        ).pack(side="left", padx=6)

        ttk.Button(
            actions,
            text="Choose Attachment(s)",
            command=self._choose_attachments,
        ).pack(side="left", padx=6)

        ttk.Button(
            actions,
            text="Clear Attachments",
            command=self._clear_attachments,
        ).pack(side="left", padx=6)

        self.attachment_label = ttk.Label(
            actions,
            text="No attachments",
        )
        self.attachment_label.pack(side="right")

        send_frame = ttk.Frame(tab)
        send_frame.pack(fill="x")

        self.send_button = ttk.Button(
            send_frame,
            text="SEND EMAILS",
            style="Accent.TButton",
            command=self._start_sending,
        )
        self.send_button.pack(side="left")

        ttk.Button(
            send_frame,
            text="STOP",
            command=self._request_stop,
        ).pack(side="left", padx=8)

        ttk.Label(
            send_frame,
            textvariable=self.count_var,
        ).pack(side="right")

    def _build_recipients_tab(self, notebook):
        """Build recipient table."""
        tab = ttk.Frame(notebook, padding=14)
        notebook.add(tab, text="Recipients")

        toolbar = ttk.Frame(tab)
        toolbar.pack(fill="x", pady=(0, 10))

        ttk.Entry(
            toolbar,
            textvariable=self.csv_var,
        ).pack(side="left", fill="x", expand=True)

        ttk.Button(
            toolbar,
            text="Browse CSV",
            command=self._browse_csv,
        ).pack(side="left", padx=6)

        ttk.Button(
            toolbar,
            text="Load",
            command=self._load_recipients,
        ).pack(side="left")

        columns = ("name", "email", "company", "subject")
        self.tree = ttk.Treeview(
            tab,
            columns=columns,
            show="headings",
        )

        headings = {
            "name": "Name",
            "email": "Email",
            "company": "Company",
            "subject": "Custom Subject",
        }

        widths = {
            "name": 180,
            "email": 280,
            "company": 180,
            "subject": 220,
        }

        for column in columns:
            self.tree.heading(column, text=headings[column])
            self.tree.column(column, width=widths[column])

        self.tree.pack(fill="both", expand=True)

        ttk.Label(
            tab,
            text="CSV columns: name,email,company,subject (name and email are required).",
        ).pack(anchor="w", pady=(8, 0))

    def _build_results_tab(self, notebook):
        """Build send results table and summary."""
        tab = ttk.Frame(notebook, padding=14)
        notebook.add(tab, text="Results")

        self.summary_label = ttk.Label(
            tab,
            text="No sending run completed yet.",
            style="Heading.TLabel",
        )
        self.summary_label.pack(anchor="w", pady=(0, 10))

        columns = ("name", "email", "status", "attempts", "error")
        self.results_tree = ttk.Treeview(
            tab,
            columns=columns,
            show="headings",
        )

        headings = {
            "name": "Name",
            "email": "Email",
            "status": "Status",
            "attempts": "Attempts",
            "error": "Error",
        }

        for column in columns:
            self.results_tree.heading(column, text=headings[column])

        self.results_tree.column("name", width=170)
        self.results_tree.column("email", width=250)
        self.results_tree.column("status", width=100)
        self.results_tree.column("attempts", width=80)
        self.results_tree.column("error", width=380)

        self.results_tree.pack(fill="both", expand=True)

        ttk.Button(
            tab,
            text="Open Status CSV",
            command=self._open_status_file,
        ).pack(anchor="e", pady=(10, 0))

    def _build_help_tab(self, notebook):
        """Build setup and usage instructions."""
        tab = ttk.Frame(notebook, padding=18)
        notebook.add(tab, text="Setup & Help")

        help_text = (
            "1. Create a Gmail App Password\n"
            "   - Use a Google account with 2-Step Verification enabled.\n"
            "   - Create an App Password for this application.\n\n"
            "2. Configure your environment in the VS Code terminal:\n"
            "   Windows PowerShell:\n"
            '   $env:EMAIL_SENDER="yourgmail@gmail.com"\n'
            '   $env:EMAIL_APP_PASSWORD="your16characterapppassword"\n\n'
            "3. Prepare data/recipients.csv:\n"
            "   name,email,company,subject\n"
            "   Rahul,rahul@example.com,ABC Ltd.,\n\n"
            "4. Write your message using:\n"
            "   {name}  {email}  {company}\n\n"
            "5. Select attachments if needed and click SEND EMAILS.\n\n"
            "6. Results are written to logs/send_status.csv and detailed\n"
            "   activity is written to logs/email_sender.log.\n\n"
            "Important: Never commit or share your App Password."
        )

        text = tk.Text(tab, wrap="word", font=("Segoe UI", 10))
        text.insert("1.0", help_text)
        text.configure(state="disabled")
        text.pack(fill="both", expand=True)

    def _load_template_into_editor(self):
        """Load saved template into the message editor."""
        template = load_template(TEMPLATE_FILE)
        self.message_text.delete("1.0", "end")
        self.message_text.insert("1.0", template)

    def _save_template(self):
        """Save current message template."""
        template = self.message_text.get("1.0", "end").strip()
        ok, error = validate_template(template)
        if not ok:
            messagebox.showerror("Template Error", error)
            return
        save_template(TEMPLATE_FILE, template)
        self.status_var.set("Template saved.")
        messagebox.showinfo("Saved", "Template saved successfully.")

    def _browse_csv(self):
        """Choose a recipient CSV."""
        path = filedialog.askopenfilename(
            title="Choose recipient CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if path:
            self.csv_var.set(path)

    def _load_recipients(self, silent=False):
        """Load recipients into the table."""
        path = Path(self.csv_var.get().strip())
        recipients, warnings = load_recipients(path)
        self.recipients = recipients

        for item in self.tree.get_children():
            self.tree.delete(item)

        for recipient in recipients:
            self.tree.insert(
                "",
                "end",
                values=(
                    recipient.name,
                    recipient.email,
                    recipient.company,
                    recipient.subject,
                ),
            )

        self.count_var.set(f"{len(recipients)} recipients loaded")

        if warnings and not silent:
            messagebox.showwarning(
                "CSV Warnings",
                "\n".join(warnings[:12]),
            )

        if not silent:
            self.status_var.set(
                f"Loaded {len(recipients)} valid recipients."
            )

    def _choose_attachments(self):
        """Choose one or more attachment files."""
        paths = filedialog.askopenfilenames(
            title="Choose attachment files",
            initialdir=str(ATTACHMENTS_DIR),
        )

        if not paths:
            return

        self.attachments = list(paths)
        self.attachment_label.config(
            text=f"{len(self.attachments)} attachment(s) selected"
        )

    def _clear_attachments(self):
        """Clear selected attachments."""
        self.attachments = []
        self.attachment_label.config(text="No attachments")

    def _preview_email(self):
        """Preview a personalized message."""
        if not self.recipients:
            messagebox.showwarning(
                "Preview",
                "Load at least one valid recipient first.",
            )
            return

        template = self.message_text.get("1.0", "end").strip()
        subject = self.subject_var.get().strip() or DEFAULT_SUBJECT

        try:
            preview = personalize(template, self.recipients[0])
        except ValueError as exc:
            messagebox.showerror("Template Error", str(exc))
            return

        messagebox.showinfo(
            "Email Preview",
            f"To: {self.recipients[0].email}\n"
            f"Subject: {self.recipients[0].subject or subject}\n\n"
            f"{preview}",
        )

    def _start_sending(self):
        """Validate input and start background sending."""
        if self.sender_thread and self.sender_thread.is_alive():
            messagebox.showwarning(
                "Busy",
                "An email sending operation is already running.",
            )
            return

        sender_email = self.sender_var.get().strip()
        app_password = self.password_var.get().strip()
        subject = self.subject_var.get().strip()
        template = self.message_text.get("1.0", "end").strip()

        if not sender_email or not app_password:
            messagebox.showerror(
                "Credentials",
                "Enter your Gmail address and App Password.",
            )
            return

        ok, error = validate_subject(subject)
        if not ok:
            messagebox.showerror("Subject Error", error)
            return

        ok, error = validate_template(template)
        if not ok:
            messagebox.showerror("Template Error", error)
            return

        for attachment in self.attachments:
            ok, error = validate_attachment(attachment)
            if not ok:
                messagebox.showerror("Attachment Error", error)
                return

        if not self.recipients:
            messagebox.showerror(
                "Recipients",
                "Load at least one valid recipient.",
            )
            return

        confirm = messagebox.askyesno(
            "Confirm Sending",
            f"Send emails to {len(self.recipients)} recipient(s)?\n\n"
            "Make sure you are using a Gmail App Password.",
        )
        if not confirm:
            return

        self.stop_requested = False
        self.progress_var.set(0)
        self.send_button.config(state="disabled")
        self.status_var.set("Connecting to Gmail...")

        self.sender_thread = threading.Thread(
            target=self._send_worker,
            args=(
                sender_email,
                app_password,
                subject,
                template,
                list(self.attachments),
            ),
            daemon=True,
        )
        self.sender_thread.start()

    def _send_worker(
        self,
        sender_email,
        app_password,
        subject,
        template,
        attachments,
    ):
        """Background worker so the GUI remains responsive."""
        engine = EmailEngine(
            sender_email,
            app_password,
            logger=self.logger,
        )

        try:
            engine.connect()
            self._set_status("Connected. Sending emails...")

            summary = engine.send_bulk(
                self.recipients,
                subject,
                template,
                attachments,
                progress_callback=self._progress_callback,
                stop_callback=lambda: self.stop_requested,
            )

            self.last_summary = summary
            write_status_report(STATUS_FILE, summary.results)
            self.root.after(0, self._display_summary, summary)

        except Exception as exc:
            self.logger.exception("Sending operation failed.")
            self.root.after(
                0,
                lambda: messagebox.showerror(
                    "Sending Error",
                    f"Could not complete the operation:\n\n{exc}",
                ),
            )
            self._set_status("Sending failed.")

        finally:
            engine.disconnect()
            self.root.after(
                0,
                lambda: self.send_button.config(state="normal"),
            )

    def _progress_callback(
        self,
        index: int,
        total: int,
        result: SendResult,
    ):
        """Update GUI progress safely."""
        percent = (index / total) * 100 if total else 0
        self.root.after(
            0,
            lambda: self.progress_var.set(percent),
        )
        self._set_status(
            f"{index}/{total}: {result.email} → {result.status}"
        )

    def _set_status(self, text: str):
        """Update status label from any thread."""
        self.root.after(
            0,
            lambda: self.status_var.set(text),
        )

    def _display_summary(self, summary: SendSummary):
        """Display final delivery results."""
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)

        for result in summary.results:
            self.results_tree.insert(
                "",
                "end",
                values=(
                    result.name,
                    result.email,
                    result.status,
                    result.attempts,
                    result.error,
                ),
            )

        self.summary_label.config(
            text=(
                f"Total: {summary.total}   |   "
                f"Successful: {summary.successful}   |   "
                f"Failed: {summary.failed}   |   "
                f"Skipped: {summary.skipped}   |   "
                f"Success rate: {summary.success_rate:.1f}%"
            )
        )

        if summary.failed == 0 and summary.skipped == 0:
            messagebox.showinfo(
                "Completed",
                "All emails were sent successfully.",
            )
        else:
            messagebox.showwarning(
                "Completed with Issues",
                "Sending finished. Check the Results tab and status CSV.",
            )

    def _request_stop(self):
        """Ask the worker to stop before the next recipient."""
        self.stop_requested = True
        self.status_var.set(
            "Stop requested. Current email may finish first."
        )

    def _open_status_file(self):
        """Open the status CSV with the operating system."""
        if not STATUS_FILE.exists():
            messagebox.showinfo(
                "Status",
                "No status report exists yet.",
            )
            return

        try:
            os.startfile(STATUS_FILE)  # Windows
        except AttributeError:
            import subprocess
            import sys

            if sys.platform == "darwin":
                subprocess.Popen(["open", str(STATUS_FILE)])
            else:
                subprocess.Popen(["xdg-open", str(STATUS_FILE)])

    def run(self):
        """Start the Tkinter event loop."""
        self.root.mainloop()
