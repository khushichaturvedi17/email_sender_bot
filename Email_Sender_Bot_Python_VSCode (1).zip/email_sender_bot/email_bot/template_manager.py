"""Email template loading, saving, and personalization."""

from pathlib import Path

from .config import DEFAULT_TEMPLATE
from .models import Recipient


def load_template(path: Path) -> str:
    """Load a template or return the default template."""
    if not path.exists():
        save_template(path, DEFAULT_TEMPLATE)
        return DEFAULT_TEMPLATE

    try:
        content = path.read_text(encoding="utf-8")
        return content if content.strip() else DEFAULT_TEMPLATE
    except OSError:
        return DEFAULT_TEMPLATE


def save_template(path: Path, template: str):
    """Save a message template."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(template, encoding="utf-8")


def personalize(template: str, recipient: Recipient) -> str:
    """
    Replace supported placeholders.

    Supported:
        {name}
        {email}
        {company}
    """
    values = recipient.variables()
    try:
        return template.format(**values)
    except KeyError as exc:
        missing = str(exc).strip("'")
        raise ValueError(
            f"Unknown template placeholder: {{{missing}}}. "
            "Use only {name}, {email}, and {company}."
        ) from exc
