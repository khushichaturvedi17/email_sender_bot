# Email Sender Bot

A structured Python desktop application for sending personalized emails through Gmail SMTP.

## Features

- Tkinter graphical interface
- Gmail SMTP with STARTTLS
- Gmail App Password authentication
- CSV recipient management
- Personalized `{name}`, `{email}`, and `{company}` placeholders
- Per-recipient custom subjects
- Multiple file attachments
- Retry logic
- Background sending so the GUI remains responsive
- Stop control
- Live progress
- Success/failed/skipped statistics
- Detailed application log
- CSV send-status report
- Preview before sending
- No third-party Python packages required

## Project Structure

```text
email_sender_bot/
│
├── main.py
├── requirements.txt
├── README.md
├── .gitignore
│
├── email_bot/
│   ├── __init__.py
│   ├── config.py
│   ├── csv_manager.py
│   ├── email_engine.py
│   ├── gui.py
│   ├── logger.py
│   ├── models.py
│   ├── template_manager.py
│   └── validators.py
│
├── data/
│   ├── recipients.csv
│   └── template.txt
│
├── attachments/
│
└── logs/
```

## Requirements

- Python 3.10 or newer recommended
- VS Code
- A Gmail account with 2-Step Verification enabled
- A Gmail App Password

No `pip install` is required.

## Run in VS Code

Open the project folder in VS Code.

Open **Terminal → New Terminal**.

Check Python:

```powershell
python --version
```

Then run:

```powershell
python main.py
```

If Windows uses `py` instead:

```powershell
py main.py
```

## Gmail Security Setup

Do not use your normal Gmail account password.

Create a Gmail App Password for the account you will use.

Then set the credentials as environment variables in the VS Code terminal.

### Windows PowerShell

```powershell
$env:EMAIL_SENDER="yourgmail@gmail.com"
$env:EMAIL_APP_PASSWORD="your16characterapppassword"
python main.py
```

The App Password is not stored by this program.

For a new terminal session, set the variables again.

## CSV Format

`data/recipients.csv`:

```csv
name,email,company,subject
Rahul,rahul@example.com,ABC Ltd.,
Priya,priya@example.com,XYZ Pvt Ltd.,Monthly Report
```

Required columns:

- `name`
- `email`

Optional:

- `company`
- `subject`

A recipient-specific subject in the CSV overrides the global subject.

## Message Personalization

The template supports:

```text
{name}
{email}
{company}
```

Example:

```text
Hello {name},

This is a personalized message for {company}.

Your registered email is {email}.

Regards,
Admin Team
```

## Attachments

Use **Choose Attachment(s)** in the application.

Multiple attachments can be selected.

## Logs and Reports

After a sending run:

```text
logs/email_sender.log
logs/send_status.csv
```

The status report contains:

- timestamp
- recipient name
- recipient email
- status
- number of attempts
- error message

## Important Safety Notes

- Only send email to recipients who have given appropriate permission.
- Do not use the bot for spam or unwanted bulk mail.
- Do not hard-code passwords into Python source files.
- Do not upload App Passwords to GitHub.
- Review your recipient CSV before sending.
- Test with your own email first.

## Troubleshooting

### `Authentication failed`

Check:

1. The Gmail address is correct.
2. 2-Step Verification is enabled.
3. The App Password is correct.
4. You are using the App Password, not your normal Gmail password.
5. The environment variables are set in the current VS Code terminal.

### `No module named tkinter`

On standard Windows Python installations, Tkinter is normally included. If it is missing, install Python from the official Python installer and ensure the standard library/Tk option is included.

### CSV recipients are not loading

Check that:

- The file is saved as CSV UTF-8.
- The first row contains `name,email`.
- Email addresses are valid.
- The selected CSV path is correct.

## Testing Recommendation

Before sending to a large list:

1. Put only your own email in `recipients.csv`.
2. Set the subject to `Email Sender Bot Test`.
3. Use a small message.
4. Send one test email.
5. Verify the Results tab and `logs/send_status.csv`.
6. Only then use your real recipient list.

## Architecture

The program separates responsibilities:

- `main.py` — application entry point
- `gui.py` — desktop interface
- `email_engine.py` — SMTP and email delivery
- `csv_manager.py` — recipient loading
- `template_manager.py` — templates and personalization
- `validators.py` — input validation
- `logger.py` — logs and status reports
- `models.py` — structured data models
- `config.py` — application configuration

This makes the project easier to understand, test, maintain, and extend.
