@echo off
title Email Sender Bot
python main.py
pause
